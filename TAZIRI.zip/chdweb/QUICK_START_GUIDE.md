# 🚀 دليل البدء السريع لتطوير تطبيق TANAMIRT الجوال

## ⚡ **البدء في 10 دقائق**

### **الخطوة 1: إعداد البيئة التطويرية**

```bash
# 1. تثبيت Node.js (إذا لم يكن مثبتاً)
# تحميل من: https://nodejs.org/

# 2. تثبيت Expo CLI
npm install -g @expo/cli

# 3. إنشاء المشروع
npx create-expo-app TanamirtMobile --template blank-typescript

# 4. الانتقال للمجلد
cd TanamirtMobile

# 5. تثبيت المكتبات الأساسية
npm install @react-navigation/native @react-navigation/stack @react-navigation/bottom-tabs
npm install @react-native-async-storage/async-storage
npm install react-native-vector-icons
npm install react-native-elements
npm install react-native-gesture-handler
npm install react-native-reanimated
npm install react-native-safe-area-context
npm install react-native-screens
npm install axios
```

### **الخطوة 2: إعداد التكوين الأساسي**

#### **تحديث app.json:**
```json
{
  "expo": {
    "name": "TANAMIRT",
    "slug": "tanamirt-mobile",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "userInterfaceStyle": "light",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#f97316"
    },
    "assetBundlePatterns": [
      "**/*"
    ],
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.tanamirt.mobile"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#f97316"
      },
      "package": "com.tanamirt.mobile"
    },
    "web": {
      "favicon": "./assets/favicon.png"
    }
  }
}
```

### **الخطوة 3: إنشاء الملفات الأساسية**

#### **1. إنشاء مجلد constants:**
```bash
mkdir constants
```

#### **2. إنشاء Colors.ts:**
```typescript
// constants/Colors.ts
export const Colors = {
  primary: '#f97316',
  primaryDark: '#ea580c',
  secondary: '#6b7280',
  background: '#f9fafb',
  surface: '#ffffff',
  text: '#1f2937',
  textSecondary: '#6b7280',
  border: '#e5e7eb',
  success: '#10b981',
  error: '#ef4444',
  warning: '#f59e0b',
  info: '#3b82f6',
};
```

#### **3. إنشاء مجلد services:**
```bash
mkdir services
```

#### **4. إنشاء api.ts:**
```typescript
// services/api.ts
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_BASE_URL = 'https://your-domain.com/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default api;
```

### **الخطوة 4: إنشاء الشاشة الأولى**

#### **إنشاء مجلد screens:**
```bash
mkdir screens
```

#### **إنشاء HomeScreen.tsx:**
```typescript
// screens/HomeScreen.tsx
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { Colors } from '../constants/Colors';
import api from '../services/api';

interface Product {
  id: string;
  name: string;
  price: number;
  discount_price?: number;
  image_url?: string;
  images?: string[];
}

export default function HomeScreen() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await api.get('/products');
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>TANAMIRT</Text>
        <Text style={styles.subtitle}>أهلاً بك في متجرنا</Text>
      </View>

      <View style={styles.productsGrid}>
        {products.map((product) => (
          <TouchableOpacity key={product.id} style={styles.productCard}>
            <Image
              source={{
                uri: product.images?.[0] || product.image_url || 'https://via.placeholder.com/150',
              }}
              style={styles.productImage}
            />
            <View style={styles.productInfo}>
              <Text style={styles.productName} numberOfLines={2}>
                {product.name}
              </Text>
              <View style={styles.priceContainer}>
                {product.discount_price ? (
                  <>
                    <Text style={styles.discountPrice}>
                      {product.discount_price} دج
                    </Text>
                    <Text style={styles.originalPrice}>
                      {product.price} دج
                    </Text>
                  </>
                ) : (
                  <Text style={styles.price}>{product.price} دج</Text>
                )}
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.background,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: Colors.textSecondary,
  },
  header: {
    padding: 20,
    backgroundColor: Colors.primary,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: 'white',
    opacity: 0.9,
  },
  productsGrid: {
    padding: 16,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  productCard: {
    width: '48%',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  productImage: {
    width: '100%',
    height: 150,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  productInfo: {
    padding: 12,
  },
  productName: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 8,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  price: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.primary,
  },
  discountPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.success,
  },
  originalPrice: {
    fontSize: 14,
    color: Colors.textSecondary,
    textDecorationLine: 'line-through',
  },
});
```

### **الخطوة 5: تحديث App.tsx**

```typescript
// App.tsx
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import HomeScreen from './screens/HomeScreen';

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <HomeScreen />
    </SafeAreaProvider>
  );
}
```

### **الخطوة 6: تشغيل التطبيق**

```bash
# تشغيل التطبيق
npx expo start

# أو
npm start
```

## 📱 **اختبار التطبيق**

### **خيارات الاختبار:**

1. **Expo Go App:**
   - تثبيت Expo Go من متجر التطبيقات
   - مسح رمز QR الذي يظهر في المتصفح

2. **المحاكي:**
   - Android Studio Emulator
   - iOS Simulator (macOS فقط)

3. **الجهاز الفعلي:**
   - توصيل الهاتف بالكمبيوتر
   - تفعيل وضع المطور

## 🔧 **الخطوات التالية**

### **1. إضافة التنقل:**
```bash
npm install @react-navigation/native @react-navigation/stack
```

### **2. إنشاء شاشات إضافية:**
- شاشة تفاصيل المنتج
- شاشة تسجيل الدخول
- شاشة السلة
- شاشة الملف الشخصي

### **3. إضافة الميزات:**
- نظام المصادقة
- إدارة السلة
- نظام الطلبات
- الإشعارات

## 🐛 **حل المشاكل الشائعة**

### **مشكلة: خطأ في المكتبات**
```bash
# حذف node_modules وإعادة التثبيت
rm -rf node_modules
npm install
```

### **مشكلة: خطأ في Metro**
```bash
# إعادة تشغيل Metro
npx expo start --clear
```

### **مشكلة: خطأ في الأيقونات**
```bash
# إعادة تشغيل التطبيق
# أو إعادة تشغيل المحاكي
```

## 📚 **الموارد المفيدة**

- [Expo Documentation](https://docs.expo.dev/)
- [React Navigation](https://reactnavigation.org/)
- [React Native Elements](https://reactnativeelements.com/)
- [React Native Vector Icons](https://github.com/oblador/react-native-vector-icons)

## 🎯 **النتيجة المتوقعة**

بعد اتباع هذا الدليل، ستحصل على:
- تطبيق React Native أساسي يعمل
- شاشة رئيسية تعرض المنتجات
- اتصال مع API الموقع
- تصميم متجاوب وجميل
- أساس قوي للتطوير المستقبلي

---

*هذا الدليل يوفر نقطة بداية سريعة. يمكنك تطويره حسب احتياجاتك.*
