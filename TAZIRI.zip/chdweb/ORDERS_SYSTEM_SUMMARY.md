# نظام حفظ الطلبات - الإصدار المكتمل 🛒

## 🎯 نظرة عامة على النظام

تم إنشاء نظام شامل لحفظ الطلبات في قاعدة البيانات مع جميع المعلومات المطلوبة:

### ✅ **المعلومات المحفوظة**:

#### 1. **معلومات المنتج**:
- `item_type`: نوع العنصر ('product' أو 'offer')
- `item_id`: معرف المنتج/العرض
- `item_name`: اسم المنتج
- `original_price`: السعر الأصلي
- `reseller_price`: سعر البيع المخصص

#### 2. **معلومات الطلب**:
- `quantity`: الكمية المطلوبة
- `unit_price`: سعر الوحدة
- `subtotal`: المجموع الفرعي
- `shipping_cost`: تكلفة الشحن
- `total_amount`: المبلغ الإجمالي

#### 3. **معلومات البائع**:
- `seller_id`: معرف البائع
- `seller_name`: اسم البائع
- `seller_phone`: رقم هاتف البائع

#### 4. **معلومات المشتري**:
- `customer_name`: اسم العميل
- `customer_phone`: رقم هاتف العميل

#### 5. **معلومات التوصيل**:
- `delivery_type`: نوع التوصيل ('home' أو 'stopDesk')
- `wilaya`: الولاية
- `commune`: البلدية (للتوصيل للمنزل)

#### 6. **معلومات إضافية**:
- `status`: حالة الطلب (افتراضي: 'pending')
- `order_link`: رابط الطلب
- `created_at`: تاريخ إنشاء الطلب

## 🗄️ هيكل قاعدة البيانات

### ✅ **جدول الطلبات (orders)**:

```sql
CREATE TABLE orders (
  id uuid PRIMARY KEY,
  item_type VARCHAR(20) NOT NULL,
  item_id uuid NOT NULL,
  item_name VARCHAR(255) NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  shipping_cost DECIMAL(10,2) NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  customer_name VARCHAR(255) NOT NULL,
  phone_number VARCHAR(50) NOT NULL,
  wilaya VARCHAR(255) NOT NULL,
  commune VARCHAR(255),
  delivery_type VARCHAR(20) NOT NULL,
  status VARCHAR(20) NOT NULL,
  reseller_price DECIMAL(10,2),
  created_at TIMESTAMP,
  reseller_name VARCHAR(255),
  reseller_phone VARCHAR(50),
  reseller_user_id uuid,
  order_link VARCHAR(255),
  seller_id uuid,
  seller_name VARCHAR(255),
  image_url TEXT
);
```

## 🔧 API الطلبات

### ✅ **إنشاء طلب جديد (POST /api/orders)**:

```typescript
// البيانات المطلوبة
{
  resell_link_id: string,
  item_type: 'product' | 'offer',
  item_id: string,
  item_name: string,
  original_price: number,
  reseller_price: number,
  quantity: number,
  total_amount: number,
  seller_id?: string,
  seller_name?: string,
  seller_phone?: string,
  customer_name: string,
  customer_phone: string,
  delivery_type: 'home' | 'stopDesk',
  wilaya: number,
  commune?: string,
  notes?: string
}

// الاستجابة
{
  success: true,
  message: 'تم حفظ الطلب بنجاح',
  order: {
    id: string,
    order_number: string,
    created_at: string
  }
}
```

### ✅ **جلب الطلبات (GET /api/orders)**:

```typescript
// المعاملات الاختيارية
?customer_phone=123456789
?status=pending

// الاستجابة
{
  success: true,
  orders: [
    {
      id: string,
      item_type: string,
      item_name: string,
      quantity: number,
      total_amount: number,
      customer_name: string,
      status: string,
      created_at: string,
      // ... باقي الحقول
    }
  ]
}
```

## 🎨 واجهة المستخدم

### ✅ **صفحة الطلب المحدثة**:

تم تحديث صفحة `/resell/[slug]` لتتوافق مع API الجديد:

#### 1. **إرسال البيانات**:
```typescript
const orderData = {
  resell_link_id: data?.link?.id,
  item_type: data?.link?.item_type,
  item_id: data?.item?.id,
  item_name: data?.item?.name,
  original_price: data?.item?.original_price,
  reseller_price: data?.link?.custom_price || data?.item?.original_price,
  quantity: quantity,
  total_amount: total,
  seller_id: data?.link?.user_id,
  seller_name: data?.reseller?.name,
  seller_phone: data?.reseller?.phone,
  customer_name: customerName.trim(),
  customer_phone: customerPhone.replace(/\s/g, ""),
  delivery_type: deliveryType,
  wilaya: wilaya,
  commune: deliveryType === 'home' ? commune?.trim() : null,
  notes: `طلب من رابط البيع: ${slug}`
};
```

#### 2. **معالجة الاستجابة**:
```typescript
if (response.ok) {
  const result = await response.json();
  alert(`تم إرسال الطلب بنجاح! رقم الطلب: ${result.order.order_number}`);
  
  // إعادة تعيين النموذج
  setQuantity(1);
  setCustomerName("");
  setCustomerPhone("");
  setWilaya(16);
  setCommune("");
  setDeliveryType('home');
}
```

## 🔄 تدفق العملية

### ✅ **خطوات حفظ الطلب**:

1. **التحقق من البيانات**: التأكد من وجود جميع الحقول المطلوبة
2. **إنشاء رقم الطلب**: توليد رقم فريد للطلب
3. **حفظ في قاعدة البيانات**: إدراج الطلب مع جميع المعلومات
4. **تحديث الإحصائيات**: زيادة عدد النقرات على رابط البيع
5. **إرجاع النتيجة**: إرجاع رقم الطلب وتأكيد الحفظ

### ✅ **معالجة الأخطاء**:

```typescript
try {
  // عملية حفظ الطلب
} catch (error) {
  console.error('خطأ في حفظ الطلب:', error);
  return NextResponse.json(
    { error: 'حدث خطأ أثناء حفظ الطلب' },
    { status: 500 }
  );
}
```

## 📊 المميزات الإضافية

### ✅ **تحديث الإحصائيات**:
- تحديث عدد النقرات على رابط البيع تلقائياً
- تتبع نشاط البيع لكل رابط

### ✅ **رقم الطلب الفريد**:
- تنسيق: `ORD-{timestamp}-{random}`
- مثال: `ORD-1756410385487-abc123def`

### ✅ **حالة الطلب**:
- `pending`: في انتظار التأكيد
- `confirmed`: مؤكد
- `shipped`: تم الشحن
- `delivered`: تم التوصيل
- `cancelled`: ملغي

## 🎯 الاستخدام

### ✅ **اختبار النظام**:

1. **زيارة صفحة الطلب**:
   ```
   http://localhost:3000/resell/test-offer-123
   ```

2. **ملء النموذج**:
   - إدخال معلومات العميل
   - اختيار الكمية
   - تحديد معلومات التوصيل

3. **إرسال الطلب**:
   - الضغط على "اطلب الآن"
   - انتظار رسالة التأكيد مع رقم الطلب

4. **التحقق من الحفظ**:
   ```
   GET /api/orders?customer_phone=123456789
   ```

## 🏆 النتيجة النهائية

### ✅ **النظام المكتمل**:

1. **✅ قاعدة بيانات**: جدول طلبات شامل
2. **✅ API**: نقاط نهاية لإنشاء وجلب الطلبات
3. **✅ واجهة مستخدم**: نموذج طلب متكامل
4. **✅ معالجة أخطاء**: رسائل خطأ واضحة
5. **✅ تتبع**: إحصائيات وتواريخ
6. **✅ أرقام فريدة**: لكل طلب رقم مميز

### ✅ **المعلومات المحفوظة**:
- ✅ اسم المنتج
- ✅ سعره (الأصلي والمخصص)
- ✅ الكمية
- ✅ البائع (المعلومات الكاملة)
- ✅ المشتري (الاسم والهاتف)
- ✅ معلومات التوصيل
- ✅ نوع العنصر ومعرفه
- ✅ جميع التفاصيل المطلوبة

النظام جاهز للاستخدام النهائي! 🚀
