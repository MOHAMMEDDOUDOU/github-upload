'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Phone, MessageCircle, ShoppingCart, Star, Eye, MousePointer, User, MapPin } from 'lucide-react';
import Image from 'next/image';

const WILAYAS = [
  { code: 1, name: "أدرار", tarif: 1400, stopDesk: 900 },
  { code: 2, name: "الشلف", tarif: 850, stopDesk: 450 },
  { code: 3, name: "الأغواط", tarif: 950, stopDesk: 550 },
  { code: 4, name: "أم البواقي", tarif: 900, stopDesk: 500 },
  { code: 5, name: "باتنة", tarif: 900, stopDesk: 500 },
  { code: 6, name: "بجاية", tarif: 800, stopDesk: 400 },
  { code: 7, name: "بسكرة", tarif: 950, stopDesk: 550 },
  { code: 8, name: "بشار", tarif: 1200, stopDesk: 800 },
  { code: 9, name: "البليدة", tarif: 600, stopDesk: 350 },
  { code: 10, name: "البويرة", tarif: 750, stopDesk: 400 },
  { code: 11, name: "تمنراست", tarif: 1600, stopDesk: 1200 },
  { code: 12, name: "تبسة", tarif: 1000, stopDesk: 600 },
  { code: 13, name: "تلمسان", tarif: 900, stopDesk: 500 },
  { code: 14, name: "تيارت", tarif: 850, stopDesk: 450 },
  { code: 15, name: "تيزي وزو", tarif: 750, stopDesk: 400 },
  { code: 16, name: "الجزائر", tarif: 500, stopDesk: 300 },
  { code: 17, name: "الجلفة", tarif: 900, stopDesk: 500 },
  { code: 18, name: "جيجل", tarif: 850, stopDesk: 450 },
  { code: 19, name: "سطيف", tarif: 800, stopDesk: 450 },
  { code: 20, name: "سعيدة", tarif: 900, stopDesk: 500 },
  { code: 21, name: "سكيكدة", tarif: 850, stopDesk: 450 },
  { code: 22, name: "سيدي بلعباس", tarif: 900, stopDesk: 500 },
  { code: 23, name: "عنابة", tarif: 900, stopDesk: 500 },
  { code: 24, name: "قالمة", tarif: 900, stopDesk: 500 },
  { code: 25, name: "قسنطينة", tarif: 850, stopDesk: 450 },
  { code: 26, name: "المدية", tarif: 700, stopDesk: 400 },
  { code: 27, name: "مستغانم", tarif: 850, stopDesk: 450 },
  { code: 28, name: "المسيلة", tarif: 850, stopDesk: 450 },
  { code: 29, name: "معسكر", tarif: 850, stopDesk: 450 },
  { code: 30, name: "ورقلة", tarif: 1100, stopDesk: 700 },
  { code: 31, name: "وهران", tarif: 800, stopDesk: 450 },
  { code: 32, name: "البيض", tarif: 1000, stopDesk: 600 },
  { code: 33, name: "إليزي", tarif: 1600, stopDesk: 1200 },
  { code: 34, name: "برج بوعريريج", tarif: 800, stopDesk: 450 },
  { code: 35, name: "بومرداس", tarif: 650, stopDesk: 350 },
  { code: 36, name: "الطارف", tarif: 950, stopDesk: 550 },
  { code: 37, name: "تندوف", tarif: 1500, stopDesk: 1100 },
  { code: 38, name: "تيسمسيلت", tarif: 850, stopDesk: 450 },
  { code: 39, name: "الوادي", tarif: 1000, stopDesk: 600 },
  { code: 40, name: "خنشلة", tarif: 950, stopDesk: 550 },
  { code: 41, name: "سوق أهراس", tarif: 950, stopDesk: 550 },
  { code: 42, name: "تيبازة", tarif: 650, stopDesk: 350 },
  { code: 43, name: "ميلة", tarif: 850, stopDesk: 450 },
  { code: 44, name: "عين الدفلى", tarif: 750, stopDesk: 400 },
  { code: 45, name: "النعامة", tarif: 1100, stopDesk: 700 },
  { code: 46, name: "عين تموشنت", tarif: 850, stopDesk: 450 },
  { code: 47, name: "غرداية", tarif: 1000, stopDesk: 600 },
  { code: 48, name: "غليزان", tarif: 850, stopDesk: 450 },
  { code: 49, name: "تيميمون", tarif: 1400, stopDesk: 900 },
  { code: 50, name: "برج باجي مختار", tarif: 1500, stopDesk: 1100 },
  { code: 51, name: "أولاد جلال", tarif: 1000, stopDesk: 600 },
  { code: 52, name: "بني عباس", tarif: 1300, stopDesk: 900 },
  { code: 53, name: "عين صالح", tarif: 1500, stopDesk: 1100 },
  { code: 54, name: "عين قزام", tarif: 1600, stopDesk: 1200 },
  { code: 55, name: "تقرت", tarif: 1000, stopDesk: 600 },
  { code: 56, name: "جانت", tarif: 1600, stopDesk: 1200 },
  { code: 57, name: "المغير", tarif: 1100, stopDesk: 700 },
  { code: 58, name: "المنيعة", tarif: 1200, stopDesk: 800 },
];

const COMMUNES: { [key: number]: string[] } = {
  16: [
    "الجزائر الوسطى",
    "باب الزوار",
    "باب الوادي",
    "بئر مراد رايس",
    "بئر توتة",
    "بئر خادم",
    "باش جراح",
    "بلكور",
    "بني مسوس",
    "برج البحري",
    "برج الكيفان",
    "الحراش",
    "حسين داي",
    "المحمدية",
    "القبة",
    "سيدي امحمد",
    "الدار البيضاء",
    "العاشور",
    "بوزريعة",
    "الرويبة",
    "رغاية",
    "الخروبة",
    "الحمامات",
    "سيدي موسى",
    "أولاد فايت",
    "سوق الأحد",
    "زرالدة",
    "الدويرة",
    "تسالة المرجة",
    "أولاد شبل",
    "شراقة",
    "حرازة",
    "المرادية",
  ],
  // يمكن إضافة باقي الولايات حسب الحاجة
};

interface ResellLinkData {
  link: {
    id: string;
    slug: string;
    item_type: string;
    item_id: string;
    reseller: {
      user_id: string | null;
      name: string | null;
      phone: string | null;
    };
    custom_price: number | null;
    is_active: boolean;
    expires_at: string | null;
    stats: {
      views: number;
      clicks: number;
    };
  };
  item: {
    id: string;
    name: string;
    description: string | null;
    original_price: number;
    custom_price: number | null;
    final_price: number;
    image_url: string | null;
    category: string | null;
    stock_quantity: number;
  };
}

export default function ResellOrderPage() {
  const params = useParams();
  const router = useRouter();
  const [data, setData] = useState<ResellLinkData | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // نموذج الطلب
  const [quantity, setQuantity] = useState(1);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [wilaya, setWilaya] = useState(16);
  const [commune, setCommune] = useState("");
  const [deliveryType, setDeliveryType] = useState("home");
  const [address, setAddress] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const slug = params.slug as string;
        const response = await fetch(`/api/resell-links/${slug}`);
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'خطأ في جلب البيانات');
        }

        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'خطأ غير متوقع');
      } finally {
        setLoading(false);
      }
    };

    if (params.slug) {
      fetchData();
    }
  }, [params.slug]);

  const selectedWilaya = WILAYAS.find((w) => w.code === Number(wilaya));
  const communesList = COMMUNES[wilaya] || [];
  const shipping = deliveryType === "home" ? selectedWilaya?.tarif || 0 : selectedWilaya?.stopDesk || 0;
  const unitPrice = data?.item.final_price || 0;
  const subtotal = unitPrice * quantity;
  const total = subtotal + shipping;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!data) return;
    
    if (!customerName.trim() || !customerPhone.trim()) {
      alert("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    if (deliveryType === "home" && !commune.trim()) {
      alert("يرجى اختيار البلدية");
      return;
    }

    setSubmitting(true);

    try {
      // تحديث عدد النقرات
      await fetch(`/api/resell-links/${data.link.slug}`, {
        method: 'POST'
      });

      const payload = {
        item_type: data.link.item_type,
        item_id: data.item.id,
        item_name: data.item.name,
        quantity,
        unit_price: unitPrice,
        subtotal,
        shipping_cost: shipping,
        total_amount: total,
        customer_name: customerName.trim(),
        phone_number: customerPhone.replace(/\s/g, ""),
        wilaya: selectedWilaya?.name.trim() || "",
        commune: deliveryType === 'home' ? commune?.trim() : 'غير محدد',
        delivery_type: deliveryType,
        address: address.trim(),
        reseller_price: data.link.custom_price,
        reseller_name: data.link.reseller.name,
        reseller_phone: data.link.reseller.phone,
        resell_link_id: data.link.id,
        resell_link_slug: data.link.slug,
      };

      const res = await fetch('/api/orders', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json' }, 
        body: JSON.stringify(payload) 
      });

      if (res.ok) {
        router.push("/order/success");
      } else {
        const errorData = await res.json();
        alert(errorData.error || "حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى.");
      }
    } catch (error) {
      console.error('خطأ في إرسال الطلب:', error);
      alert("حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى.");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري تحميل البيانات...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center p-6">
            <div className="text-red-500 mb-4">
              <MessageCircle className="h-12 w-12 mx-auto" />
            </div>
            <h2 className="text-xl font-semibold mb-2">خطأ</h2>
            <p className="text-gray-600">{error || 'الرابط غير موجود أو منتهي الصلاحية'}</p>
            <Button 
              onClick={() => router.back()} 
              className="mt-4"
            >
              العودة للصفحة السابقة
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const hasDiscount = data.item.custom_price && data.item.custom_price < data.item.original_price;
  const discountPercentage = hasDiscount 
    ? Math.round(((data.item.original_price - data.item.custom_price) / data.item.original_price) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">طلب من {data.link.reseller.name}</h1>
          <p className="text-gray-600">عرض خاص - {data.item.name}</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* معلومات المنتج */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="h-5 w-5 text-pink-500" />
                معلومات المنتج
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="relative h-48 bg-gray-100 rounded-lg overflow-hidden">
                {data.item.image_url ? (
                  <Image
                    src={data.item.image_url}
                    alt={data.item.name}
                    fill
                    className="object-cover"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-gray-400 text-center">
                      <ShoppingCart className="h-16 w-16 mx-auto mb-2" />
                      <p>لا توجد صورة</p>
                    </div>
                  </div>
                )}
                {hasDiscount && (
                  <Badge className="absolute top-2 right-2 bg-red-500 text-white">
                    -{discountPercentage}%
                  </Badge>
                )}
              </div>
              
              <div>
                <h3 className="font-semibold text-lg mb-2">{data.item.name}</h3>
                {data.item.category && (
                  <Badge variant="outline" className="mb-2">
                    {data.item.category}
                  </Badge>
                )}
                {data.item.description && (
                  <p className="text-gray-600 text-sm">{data.item.description}</p>
                )}
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">السعر الأصلي:</span>
                  <span className="text-gray-400 line-through">
                    {data.item.original_price.toLocaleString()} دج
                  </span>
                </div>
                {hasDiscount && (
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">السعر المخصص:</span>
                    <span className="text-green-600 font-semibold">
                      {data.item.custom_price?.toLocaleString()} دج
                    </span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold">السعر النهائي:</span>
                  <span className="text-2xl font-bold text-pink-600">
                    {data.item.final_price.toLocaleString()} دج
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* معلومات البائع */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                معلومات البائع
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl font-bold text-pink-600">
                    {data.link.reseller.name?.charAt(0) || '?'}
                  </span>
                </div>
                <h3 className="font-semibold text-lg">{data.link.reseller.name}</h3>
                <p className="text-gray-600">بائع معتمد</p>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-gray-500" />
                  <div>
                    <p className="font-medium">رقم الهاتف</p>
                    <p className="text-gray-600">{data.link.reseller.phone}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <MessageCircle className="h-5 w-5 text-gray-500" />
                  <div>
                    <p className="font-medium">طريقة التواصل</p>
                    <p className="text-gray-600">WhatsApp متاح</p>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h4 className="font-semibold">مميزات هذا العرض:</h4>
                <ul className="space-y-1 text-sm text-gray-600">
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    سعر مخصص ومميز
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    توصيل سريع وآمن
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    ضمان الجودة
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    دعم فني متواصل
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* نموذج الطلب */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-blue-500" />
                نموذج الطلب
              </CardTitle>
            </CardHeader>
            
            <CardContent>
              {/* ملخص الطلب */}
              <div className="p-4 bg-gray-50 rounded-lg mb-6">
                <h4 className="font-semibold mb-3">ملخص الطلب:</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>سعر الوحدة:</span>
                    <span>{unitPrice.toLocaleString()} دج</span>
                  </div>
                  <div className="flex justify-between">
                    <span>الكمية:</span>
                    <span>{quantity}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>المجموع الفرعي:</span>
                    <span>{subtotal.toLocaleString()} دج</span>
                  </div>
                  <div className="flex justify-between">
                    <span>تكلفة الشحن:</span>
                    <span>{shipping.toLocaleString()} دج</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>الإجمالي:</span>
                    <span className="text-pink-600">{total.toLocaleString()} دج</span>
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* الكمية */}
                <div>
                  <label className="font-medium text-gray-700 block mb-2">الكمية:</label>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-10 h-10 rounded-full bg-pink-500 text-white font-bold hover:bg-pink-600 transition"
                    >
                      -
                    </button>
                    <span className="w-12 text-center font-bold text-lg">{quantity}</span>
                    <button
                      type="button"
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-10 h-10 rounded-full bg-pink-500 text-white font-bold hover:bg-pink-600 transition"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* معلومات العميل */}
                <div>
                  <label className="font-medium text-gray-700 block mb-2">الاسم الكامل *</label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    required
                    className="w-full rounded-lg border-2 border-gray-300 px-3 py-2 focus:border-pink-400 focus:outline-none"
                    placeholder="أدخل اسمك الكامل"
                  />
                </div>

                <div>
                  <label className="font-medium text-gray-700 block mb-2">رقم الهاتف *</label>
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    required
                    className="w-full rounded-lg border-2 border-gray-300 px-3 py-2 focus:border-pink-400 focus:outline-none"
                    placeholder="أدخل رقم هاتفك"
                  />
                </div>

                {/* نوع التوصيل */}
                <div>
                  <label className="font-medium text-gray-700 block mb-2">نوع التوصيل</label>
                  <select
                    value={deliveryType}
                    onChange={(e) => setDeliveryType(e.target.value)}
                    className="w-full rounded-lg border-2 border-gray-300 px-3 py-2 focus:border-pink-400 focus:outline-none"
                  >
                    <option value="home">توصيل للمنزل</option>
                    <option value="stopDesk">توصيل للمكتب</option>
                  </select>
                </div>

                {/* الولاية */}
                <div>
                  <label className="font-medium text-gray-700 block mb-2">الولاية</label>
                  <select
                    value={wilaya}
                    onChange={(e) => setWilaya(Number(e.target.value))}
                    className="w-full rounded-lg border-2 border-gray-300 px-3 py-2 focus:border-pink-400 focus:outline-none"
                  >
                    {WILAYAS.map((w) => (
                      <option key={w.code} value={w.code}>
                        {w.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* البلدية - للمنزل فقط */}
                {deliveryType === "home" && (
                  <div>
                    <label className="font-medium text-gray-700 block mb-2">البلدية *</label>
                    <select
                      value={commune}
                      onChange={(e) => setCommune(e.target.value)}
                      required={deliveryType === "home"}
                      className="w-full rounded-lg border-2 border-gray-300 px-3 py-2 focus:border-pink-400 focus:outline-none"
                    >
                      <option value="">اختر البلدية</option>
                      {communesList.map((c: string) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* العنوان - للمنزل فقط */}
                {deliveryType === "home" && (
                  <div>
                    <label className="font-medium text-gray-700 block mb-2">العنوان التفصيلي</label>
                    <textarea
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full rounded-lg border-2 border-gray-300 px-3 py-2 focus:border-pink-400 focus:outline-none"
                      rows={3}
                      placeholder="أدخل العنوان التفصيلي (اختياري)"
                    />
                  </div>
                )}

                {/* زر الطلب */}
                <Button
                  type="submit"
                  disabled={submitting || (data.item.stock_quantity !== undefined && quantity > data.item.stock_quantity)}
                  className={`w-full py-3 rounded-xl font-bold text-lg transition-all ${
                    submitting || (data.item.stock_quantity !== undefined && quantity > data.item.stock_quantity)
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-pink-600 hover:bg-pink-700 text-white'
                  }`}
                >
                  {submitting ? 'جاري إرسال الطلب...' : 'اطلب الآن'}
                </Button>

                {data.item.stock_quantity !== undefined && quantity > data.item.stock_quantity && (
                  <div className="text-center text-red-600 font-bold mt-2">
                    المخزون غير كافٍ لهذه الكمية المطلوبة.
                  </div>
                )}
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-sm text-gray-500">
          <p>هذا العرض صالح حتى: {data.link.expires_at ? new Date(data.link.expires_at).toLocaleDateString('ar-SA') : 'غير محدد'}</p>
        </div>
      </div>
    </div>
  );
}
