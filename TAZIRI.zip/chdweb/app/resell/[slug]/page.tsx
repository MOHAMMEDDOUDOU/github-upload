'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Phone, MessageCircle, ShoppingCart, Star, User, MapPin } from 'lucide-react';
import Image from 'next/image';
import { WILAYAS, COMMUNES_BY_CODE } from '@/lib/locations';

interface ResellLinkData {
  link: {
    id: string;
    slug: string;
    item_type: string;
    item_id: string;
    reseller: {
      user_id: string | null;
      name: string | null;
      phone: string | null;
    };
    custom_price: number | null;
    is_active: boolean;
    expires_at: string | null;
    stats: {
      views: number;
      clicks: number;
    };
  };
  item: {
    id: string;
    name: string;
    description: string | null;
    original_price: number;
    custom_price: number | null;
    final_price: number;
    image_url: string | null;
    category: string | null;
    stock_quantity: number;
  };
}

export default function ResellLinkPage() {
  const params = useParams();
  const [data, setData] = useState<ResellLinkData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  
  // نموذج الطلب
  const [quantity, setQuantity] = useState(1);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [wilaya, setWilaya] = useState(16);
  const [commune, setCommune] = useState("");
  const [deliveryType, setDeliveryType] = useState("home");
  const [address, setAddress] = useState("");
  const [availableCommunes, setAvailableCommunes] = useState<string[]>([]);

  // تحديث البلديات المتاحة عند تغيير الولاية
  useEffect(() => {
    const communes = COMMUNES_BY_CODE[wilaya] || [];
    setAvailableCommunes(communes);
    setCommune(""); // إعادة تعيين البلدية عند تغيير الولاية
  }, [wilaya]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const slug = params.slug as string;
        
        // جلب البيانات الفعلية من API
        const response = await fetch(`/api/resell-links/${slug}`);
        
        if (!response.ok) {
          if (response.status === 404) {
            setError('الرابط غير موجود أو منتهي الصلاحية');
          } else {
            setError('حدث خطأ في جلب البيانات');
          }
          setLoading(false);
          return;
        }
        
        const apiData = await response.json();
        
        // تأخير صغير لتجنب مشاكل Hydration
        setTimeout(() => {
          setData(apiData);
          setLoading(false);
        }, 100);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'خطأ غير متوقع');
        setLoading(false);
      }
    };

    if (params.slug) {
      fetchData();
    }
  }, [params.slug]);

  const shipping = deliveryType === "home" ? 500 : 300;
  const unitPrice = data?.item?.custom_price || data?.item?.original_price || 0;
  const subtotal = unitPrice * quantity;
  const total = subtotal + shipping;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!data) return;
    
    if (!customerName.trim() || !customerPhone.trim()) {
      alert("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    if (deliveryType === "home" && !commune.trim()) {
      alert("يرجى اختيار البلدية");
      return;
    }

    setSubmitting(true);

    try {
      const orderData = {
        resell_link_id: data?.link?.id,
        item_type: data?.link?.item_type,
        item_id: data?.item?.id,
        item_name: data?.item?.name,
        original_price: data?.item?.original_price,
        reseller_price: data?.link?.custom_price || data?.item?.original_price,
        quantity: quantity,
        total_amount: total,
        seller_id: data?.link?.reseller?.user_id || null,
        seller_name: data?.link?.reseller?.name || null,
        seller_phone: data?.link?.reseller?.phone || null,
        customer_name: customerName.trim(),
        customer_phone: customerPhone.replace(/\s/g, ""),
        delivery_type: deliveryType,
        wilaya: wilaya,
        commune: deliveryType === 'home' ? commune?.trim() : null,
        notes: `طلب من رابط البيع: ${params.slug}`
      };

      const apiUrl = `${window.location.origin}/api/orders`;
      console.log('submit:start', { apiUrl, orderData });

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache'
        },
        body: JSON.stringify(orderData),
      });

      console.log('submit:response', { status: response.status });

      if (response.ok) {
        const result = await response.json();
        console.log('submit:success', result);
        alert(`تم إرسال الطلب بنجاح! رقم الطلب: ${result.order.order_number}`);
        
        // إعادة تعيين النموذج
        setQuantity(1);
        setCustomerName("");
        setCustomerPhone("");
        setWilaya(16);
        setCommune("");
        setDeliveryType('home');
      } else {
        const raw = await response.text();
        let parsed: any = null;
        try { parsed = JSON.parse(raw); } catch {}
        console.error('فشل إرسال الطلب:', { status: response.status, body: raw });
        alert((parsed && parsed.error) || 'حدث خطأ أثناء إرسال الطلب');
      }
    } catch (error) {
      console.error('خطأ في إرسال الطلب:', error);
      alert("حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى.");
    } finally {
      console.log('submit:done');
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري تحميل البيانات...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center p-6">
            <div className="text-red-500 mb-4">
              <MessageCircle className="h-12 w-12 mx-auto" />
            </div>
            <h2 className="text-xl font-semibold mb-2">خطأ</h2>
            <p className="text-gray-600">{error || 'الرابط غير موجود أو منتهي الصلاحية'}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const hasDiscount = data?.item.custom_price && data.item.custom_price < data.item.original_price;
  const discountPercentage = hasDiscount && data 
    ? Math.round(((data.item.original_price - data.item.custom_price) / data.item.original_price) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 py-6 sm:py-8 md:py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
        {/* Header */}
        <div className="text-center mb-8 sm:mb-10 md:mb-12">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-800 mb-2 sm:mb-3">طلب المنتج</h1>
          <p className="text-base sm:text-lg text-gray-600">أكمل طلبك الآن بسهولة</p>
        </div>

        <div className="max-w-2xl mx-auto">
          {/* معلومات المنتج */}
          <Card className="shadow-lg border-0 mb-6 sm:mb-8">
            <CardHeader className="pb-3 sm:pb-4">
              <CardTitle className="flex items-center gap-2 sm:gap-3 text-lg sm:text-xl">
                <ShoppingCart className="h-5 w-5 sm:h-6 sm:w-6 text-blue-500" />
                معلومات المنتج
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-4 sm:space-y-6">
              <div className="relative h-48 sm:h-64 md:h-80 bg-gray-100 rounded-lg overflow-hidden">
                {data?.item?.image_url ? (
                  <Image
                    src={data.item.image_url}
                    alt={data?.item?.name || 'المنتج'}
                    fill
                    className="object-cover"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-gray-400 text-center">
                      <ShoppingCart className="h-16 w-16 mx-auto mb-2" />
                      <p>لا توجد صورة</p>
                    </div>
                  </div>
                )}
              </div>
              
              <div>
                <h3 className="font-semibold text-lg sm:text-xl mb-2">{data?.item?.name || 'المنتج'}</h3>
                {data?.item?.category && (
                  <Badge variant="outline" className="mb-2 text-xs sm:text-sm">
                    {data.item.category}
                  </Badge>
                )}
                {data?.item?.description && (
                  <p className="text-gray-600 text-xs sm:text-sm mb-3 sm:mb-4">{data.item.description}</p>
                )}
              </div>

              <Separator />

              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-orange-600">
                  {(data?.item?.custom_price || data?.item?.original_price || 0).toLocaleString('fr-FR')} دج
                </div>
                <p className="text-xs sm:text-sm text-gray-500 mt-1">السعر المخصص</p>
              </div>
            </CardContent>
          </Card>

          {/* نموذج الطلب */}
          <Card className="shadow-lg border-0">
            <CardHeader className="pb-3 sm:pb-4">
              <CardTitle className="flex items-center gap-2 sm:gap-3 text-lg sm:text-xl">
                <User className="h-5 w-5 sm:h-6 sm:w-6 text-orange-500" />
                نموذج الطلب
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-4 sm:space-y-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* الكمية */}
                <div>
                  <label className="font-semibold text-gray-700 block mb-2 sm:mb-3 text-base sm:text-lg flex items-center gap-2">
                    <ShoppingCart className="h-4 w-4 sm:h-5 sm:w-5 text-blue-500" />
                    الكمية المطلوبة:
                  </label>
                  <div className="flex items-center justify-center gap-3 sm:gap-4">
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-blue-500 text-white font-bold text-lg sm:text-xl hover:bg-blue-600 transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105"
                    >
                      -
                    </button>
                    <div className="w-14 h-10 sm:w-16 sm:h-12 flex items-center justify-center text-xl sm:text-2xl font-bold text-gray-700 bg-gray-100 rounded-lg border-2 border-gray-200">
                      {quantity}
                    </div>
                    <button
                      type="button"
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-blue-500 text-white font-bold text-lg sm:text-xl hover:bg-blue-600 transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* معلومات العميل */}
                <div>
                  <label className="font-semibold text-gray-700 block mb-2 sm:mb-3 text-base sm:text-lg flex items-center gap-2">
                    <User className="h-4 w-4 sm:h-5 sm:w-5 text-blue-500" />
                    معلومات العميل:
                  </label>
                  <div className="space-y-3 sm:space-y-4">
                    <div>
                      <label className="font-medium text-gray-700 block mb-1 sm:mb-2 text-sm sm:text-base">الاسم الكامل *</label>
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        required
                        className="w-full rounded-xl border-2 border-gray-300 px-3 py-2 sm:px-4 sm:py-3 focus:border-blue-400 focus:outline-none text-base sm:text-lg transition-all duration-200 hover:border-gray-400"
                        placeholder="أدخل اسمك الكامل"
                      />
                    </div>

                    <div>
                      <label className="font-medium text-gray-700 block mb-1 sm:mb-2 text-sm sm:text-base">رقم الهاتف *</label>
                      <input
                        type="tel"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        required
                        className="w-full rounded-xl border-2 border-gray-300 px-3 py-2 sm:px-4 sm:py-3 focus:border-blue-400 focus:outline-none text-base sm:text-lg transition-all duration-200 hover:border-gray-400"
                        placeholder="أدخل رقم هاتفك"
                      />
                    </div>
                  </div>
                </div>

                {/* معلومات التوصيل */}
                <div>
                  <label className="font-semibold text-gray-700 block mb-2 sm:mb-3 text-base sm:text-lg flex items-center gap-2">
                    <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-orange-500" />
                    معلومات التوصيل:
                  </label>
                  <div className="space-y-3 sm:space-y-4">
                    <div>
                      <label className="font-medium text-gray-700 block mb-1 sm:mb-2 text-sm sm:text-base">نوع التوصيل</label>
                      <select
                        value={deliveryType}
                        onChange={(e) => setDeliveryType(e.target.value)}
                        className="w-full rounded-xl border-2 border-gray-300 px-3 py-2 sm:px-4 sm:py-3 focus:border-blue-400 focus:outline-none text-base sm:text-lg transition-all duration-200 hover:border-gray-400"
                      >
                        <option value="home">🏠 توصيل للمنزل</option>
                        <option value="stopDesk">📦 توصيل للمكتب</option>
                      </select>
                    </div>

                    <div>
                      <label className="font-medium text-gray-700 block mb-1 sm:mb-2 text-sm sm:text-base">الولاية</label>
                      <select
                        value={wilaya}
                        onChange={(e) => setWilaya(Number(e.target.value))}
                        className="w-full rounded-xl border-2 border-gray-300 px-3 py-2 sm:px-4 sm:py-3 focus:border-blue-400 focus:outline-none text-base sm:text-lg transition-all duration-200 hover:border-gray-400"
                      >
                        <option value={16}>الجزائر</option>
                        <option value={31}>وهران</option>
                        <option value={48}>بجاية</option>
                        <option value={19}>سطيف</option>
                        <option value={6}>بشار</option>
                        <option value={42}>تيبازة</option>
                        <option value={26}>مستغانم</option>
                        <option value={22}>سيدي بلعباس</option>
                        <option value={21}>سكيكدة</option>
                        <option value={41}>سوق أهراس</option>
                        <option value={11}>تمنراست</option>
                        <option value={12}>تبسة</option>
                        <option value={14}>تيارت</option>
                        <option value={36}>الطارف</option>
                        <option value={43}>ميلة</option>
                        <option value={27}>المسيلة</option>
                        <option value={24}>قالمة</option>
                        <option value={17}>الجلفة</option>
                        <option value={32}>البيض</option>
                        <option value={39}>الوادي</option>
                        <option value={40}>خنشلة</option>
                        <option value={28}>معسكر</option>
                        <option value={3}>الأغواط</option>
                        <option value={2}>الشلف</option>
                        <option value={20}>سعيدة</option>
                        <option value={25}>قسنطينة</option>
                        <option value={18}>جيجل</option>
                        <option value={5}>باتنة</option>
                        <option value={4}>أم البواقي</option>
                        <option value={29}>مشيرة</option>
                        <option value={23}>عنابة</option>
                        <option value={44}>عين الدفلى</option>
                        <option value={46}>عين تموشنت</option>
                        <option value={30}>ورقلة</option>
                        <option value={35}>بومرداس</option>
                        <option value={8}>بسكرة</option>
                        <option value={10}>البويرة</option>
                        <option value={34}>برج بوعريريج</option>
                        <option value={9}>البليدة</option>
                        <option value={7}>البيرين</option>
                        <option value={33}>إليزي</option>
                        <option value={45}>النعامة</option>
                        <option value={37}>تندوف</option>
                        <option value={1}>أدرار</option>
                        <option value={38}>تيسمسيلت</option>
                        <option value={15}>تيزي وزو</option>
                        <option value={13}>تلمسان</option>
                        <option value={47}>غرداية</option>
                        <option value={49}>إليزي</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* البلدية - للمنزل فقط */}
                {deliveryType === "home" && (
                  <div className="space-y-3 sm:space-y-4">
                    <div>
                      <label className="font-medium text-gray-700 block mb-1 sm:mb-2 text-sm sm:text-base">البلدية *</label>
                      <select
                        value={commune}
                        onChange={(e) => setCommune(e.target.value)}
                        required={deliveryType === "home"}
                        className="w-full rounded-xl border-2 border-gray-300 px-3 py-2 sm:px-4 sm:py-3 focus:border-blue-400 focus:outline-none text-base sm:text-lg transition-all duration-200 hover:border-gray-400"
                      >
                        <option value="">اختر البلدية</option>
                        {availableCommunes.map((communeName) => (
                          <option key={communeName} value={communeName}>
                            {communeName}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}

                {/* زر الطلب */}
                <div className="pt-4 sm:pt-6">
                  {/* تكلفة النقل والإجمالي */}
                  <div className="mb-4 sm:mb-5 rounded-xl bg-gray-50 border border-gray-200 p-4 sm:p-5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm sm:text-base text-gray-700">تكلفة النقل</span>
                      <span className="font-semibold text-gray-900 text-sm sm:text-base">
                        {Number(shipping || 0).toLocaleString('fr-FR')} دج
                      </span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex items-center justify-between">
                      <span className="text-sm sm:text-base text-gray-700">التكلفة الإجمالية</span>
                      <span className="font-bold text-lg sm:text-xl text-orange-600">
                        {Number(total || 0).toLocaleString('fr-FR')} دج
                      </span>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={submitting}
                    className={`w-full py-3 sm:py-4 rounded-2xl font-bold text-lg sm:text-xl transition-all duration-300 shadow-lg ${
                      submitting
                        ? 'bg-gray-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white hover:shadow-xl transform hover:scale-[1.02]'
                    }`}
                  >
                    {submitting ? 'جاري إرسال الطلب...' : 'اطلب الآن'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
