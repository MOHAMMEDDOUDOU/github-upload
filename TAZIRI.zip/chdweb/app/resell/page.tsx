import NotFoundPage from "@/components/NotFoundPage"

export default function ResellPage() {
  return <NotFoundPage />
}
