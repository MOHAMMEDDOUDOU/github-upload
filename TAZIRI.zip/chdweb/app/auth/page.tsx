"use client"
import NotFoundPage from "@/components/NotFoundPage"

export default function AuthPage() {
  return <NotFoundPage />
}
