import NotFoundPage from "@/components/NotFoundPage"

export default function HomePage() {
  return <NotFoundPage />
}
