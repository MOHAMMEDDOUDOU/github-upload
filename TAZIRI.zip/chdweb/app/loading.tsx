export default function Loading() {
  return <div style={{textAlign: 'center', color: 'gray', fontSize: 32, margin: 40}}>...جاري التحميل</div>;
}
