-- =====================================================
-- جدول روابط إعادة البيع (Resell Links)
-- =====================================================

-- إنشاء جدول روابط إعادة البيع
CREATE TABLE IF NOT EXISTS resell_links (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    slug VARCHAR(100) UNIQUE NOT NULL, -- الرابط المختصر مثل abc123def
    item_type VARCHAR(20) NOT NULL DEFAULT 'product', -- product | offer
    item_id UUID NOT NULL, -- معرف المنتج أو العرض
    reseller_user_id UUID, -- معرف المستخدم البائع (اختياري)
    reseller_name VARCHAR(255), -- اسم البائع (إذا لم يكن مسجل دخول)
    reseller_phone VARCHAR(30), -- رقم هاتف البائع
    custom_price DECIMAL(10,2), -- السعر المخصص للبيع
    is_active BOOLEAN DEFAULT true, -- حالة الرابط (نشط/غير نشط)
    views_count INTEGER DEFAULT 0, -- عدد مرات المشاهدة
    clicks_count INTEGER DEFAULT 0, -- عدد مرات النقر
    expires_at TIMESTAMP WITH TIME ZONE, -- تاريخ انتهاء الصلاحية (اختياري)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_resell_links_slug ON resell_links(slug);
CREATE INDEX IF NOT EXISTS idx_resell_links_item ON resell_links(item_type, item_id);
CREATE INDEX IF NOT EXISTS idx_resell_links_reseller ON resell_links(reseller_user_id);
CREATE INDEX IF NOT EXISTS idx_resell_links_active ON resell_links(is_active);
CREATE INDEX IF NOT EXISTS idx_resell_links_expires ON resell_links(expires_at);

-- إنشاء trigger لتحديث updated_at
CREATE TRIGGER update_resell_links_updated_at 
    BEFORE UPDATE ON resell_links 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- إضافة تعليقات على الجدول
COMMENT ON TABLE resell_links IS 'جدول روابط إعادة البيع للمنتجات والعروض';
COMMENT ON COLUMN resell_links.id IS 'المعرف الفريد للرابط';
COMMENT ON COLUMN resell_links.slug IS 'الرابط المختصر الفريد';
COMMENT ON COLUMN resell_links.item_type IS 'نوع العنصر (منتج أو عرض)';
COMMENT ON COLUMN resell_links.item_id IS 'معرف المنتج أو العرض';
COMMENT ON COLUMN resell_links.reseller_user_id IS 'معرف المستخدم البائع';
COMMENT ON COLUMN resell_links.reseller_name IS 'اسم البائع (إذا لم يكن مسجل دخول)';
COMMENT ON COLUMN resell_links.reseller_phone IS 'رقم هاتف البائع';
COMMENT ON COLUMN resell_links.custom_price IS 'السعر المخصص للبيع';
COMMENT ON COLUMN resell_links.is_active IS 'حالة الرابط (نشط/غير نشط)';
COMMENT ON COLUMN resell_links.views_count IS 'عدد مرات المشاهدة';
COMMENT ON COLUMN resell_links.clicks_count IS 'عدد مرات النقر';
COMMENT ON COLUMN resell_links.expires_at IS 'تاريخ انتهاء الصلاحية';
COMMENT ON COLUMN resell_links.created_at IS 'تاريخ الإنشاء';
COMMENT ON COLUMN resell_links.updated_at IS 'تاريخ آخر تحديث';
