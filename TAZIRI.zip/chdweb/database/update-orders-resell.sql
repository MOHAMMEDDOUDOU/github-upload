-- تحديث جدول الطلبات لدعم روابط إعادة البيع
-- إضافة الأعمدة الجديدة

-- إضافة عمود reseller_name
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reseller_name VARCHAR(255);

-- إضافة عمود reseller_phone
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reseller_phone VARCHAR(30);

-- إضافة عمود reseller_user_id
ALTER TABLE orders ADD COLUMN IF NOT EXISTS reseller_user_id UUID;

-- إضافة عمود resell_link_id
ALTER TABLE orders ADD COLUMN IF NOT EXISTS resell_link_id UUID;

-- إضافة عمود resell_link_slug
ALTER TABLE orders ADD COLUMN IF NOT EXISTS resell_link_slug VARCHAR(255);

-- إضافة عمود address
ALTER TABLE orders ADD COLUMN IF NOT EXISTS address TEXT;

-- إنشاء فهارس للأعمدة الجديدة
CREATE INDEX IF NOT EXISTS idx_orders_reseller ON orders(reseller_user_id);
CREATE INDEX IF NOT EXISTS idx_orders_resell_link ON orders(resell_link_id, resell_link_slug);

-- تحديث التعليقات
COMMENT ON COLUMN orders.reseller_name IS 'اسم البائع في حالة الطلب من رابط إعادة البيع';
COMMENT ON COLUMN orders.reseller_phone IS 'رقم هاتف البائع في حالة الطلب من رابط إعادة البيع';
COMMENT ON COLUMN orders.reseller_user_id IS 'معرف المستخدم البائع في حالة الطلب من رابط إعادة البيع';
COMMENT ON COLUMN orders.resell_link_id IS 'معرف رابط إعادة البيع المستخدم في الطلب';
COMMENT ON COLUMN orders.resell_link_slug IS 'الرابط المختصر لرابط إعادة البيع';
COMMENT ON COLUMN orders.address IS 'العنوان التفصيلي للتوصيل';
