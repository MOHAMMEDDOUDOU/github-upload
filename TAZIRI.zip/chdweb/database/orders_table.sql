-- إنشاء جدول الطلبات
CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    resell_link_id INTEGER REFERENCES resell_links(id),
    item_type VARCHAR(20) NOT NULL, -- 'product' or 'offer'
    item_id INTEGER NOT NULL,
    item_name VARCHAR(255) NOT NULL,
    original_price DECIMAL(10,2) NOT NULL,
    reseller_price DECIMAL(10,2) NOT NULL,
    quantity INTEGER NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    
    -- معلومات البائع
    seller_id INTEGER REFERENCES users(id),
    seller_name VARCHAR(255),
    seller_phone VARCHAR(50),
    
    -- معلومات المشتري
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(50) NOT NULL,
    
    -- معلومات التوصيل
    delivery_type VARCHAR(20) NOT NULL, -- 'home' or 'stopDesk'
    wilaya INTEGER NOT NULL,
    commune VARCHAR(255),
    
    -- حالة الطلب
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'confirmed', 'shipped', 'delivered', 'cancelled'
    
    -- معلومات إضافية
    notes TEXT,
    
    -- التواريخ
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء فهرس للبحث السريع
CREATE INDEX IF NOT EXISTS idx_orders_resell_link_id ON orders(resell_link_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer_phone ON orders(customer_phone);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);

-- إنشاء تسلسل لرقم الطلب
CREATE SEQUENCE IF NOT EXISTS order_number_seq START 1000;

-- دالة لتوليد رقم الطلب الفريد
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS VARCHAR AS $$
BEGIN
    RETURN 'ORD-' || TO_CHAR(CURRENT_DATE, 'YYYYMMDD') || '-' || LPAD(NEXTVAL('order_number_seq')::TEXT, 4, '0');
END;
$$ LANGUAGE plpgsql;

-- تحديث دالة updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- إنشاء trigger لتحديث updated_at
CREATE TRIGGER update_orders_updated_at
    BEFORE UPDATE ON orders
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
