const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function searchSpecificOrder() {
  const client = await pool.connect();
  
  try {
    console.log('🔍 البحث عن طلب محدد...');

    // البحث عن الطلب بمعرفه
    const orderId = '0d045803-8d4d-42ce-9a11-b02545e18122';
    
    const orderById = await client.query(`
      SELECT * FROM orders WHERE id = $1
    `, [orderId]);
    
    if (orderById.rows.length > 0) {
      console.log('✅ تم العثور على الطلب بمعرفه:');
      console.log(JSON.stringify(orderById.rows[0], null, 2));
    } else {
      console.log('❌ لم يتم العثور على الطلب بمعرفه:', orderId);
    }

    // البحث عن الطلب برقم الهاتف
    const phoneNumber = '0550123464';
    
    const orderByPhone = await client.query(`
      SELECT * FROM orders WHERE phone_number = $1
    `, [phoneNumber]);
    
    if (orderByPhone.rows.length > 0) {
      console.log('\n✅ تم العثور على الطلب برقم الهاتف:');
      orderByPhone.rows.forEach((order, index) => {
        console.log(`\n${index + 1}. طلب رقم: ${order.id}`);
        console.log(`   المنتج: ${order.item_name}`);
        console.log(`   العميل: ${order.customer_name}`);
        console.log(`   الهاتف: ${order.phone_number}`);
        console.log(`   المبلغ: ${order.total_amount}`);
        console.log(`   التاريخ: ${order.created_at}`);
      });
    } else {
      console.log('\n❌ لم يتم العثور على الطلب برقم الهاتف:', phoneNumber);
    }

    // البحث عن جميع الطلبات الحديثة
    const recentOrders = await client.query(`
      SELECT id, item_name, customer_name, phone_number, created_at 
      FROM orders 
      WHERE created_at > NOW() - INTERVAL '1 hour'
      ORDER BY created_at DESC
    `);
    
    console.log('\n📋 جميع الطلبات في الساعة الماضية:');
    if (recentOrders.rows.length > 0) {
      recentOrders.rows.forEach((order, index) => {
        console.log(`${index + 1}. ${order.id} - ${order.item_name} - ${order.customer_name} - ${order.created_at}`);
      });
    } else {
      console.log('لا توجد طلبات في الساعة الماضية');
    }

  } catch (error) {
    console.error('❌ خطأ في البحث:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

searchSpecificOrder().catch(console.error);
