const { exec } = require('child_process');

async function testApiWithLogs() {
  try {
    console.log('🧪 اختبار API مع سجلات مفصلة...');

    const orderData = {
      resell_link_id: "fd9e719b-ed15-4d75-8c53-8d5d36966cf6",
      item_type: "product",
      item_id: "8dae8c99-2655-41b1-91b1-7e6a088d3712",
      item_name: "منتج تجريبي للاختبار مع السجلات",
      original_price: 1500,
      reseller_price: 1800,
      quantity: 1,
      total_amount: 1800,
      seller_id: "628b27dc-dff1-490d-9b3b-b97ec4260caf",
      seller_name: "بائع تجريبي",
      seller_phone: "0550123457",
      customer_name: "عميل تجريبي مع السجلات",
      customer_phone: "0550123464",
      delivery_type: "home",
      wilaya: 16,
      commune: "بلدية تجريبية",
      notes: "طلب من رابط البيع: test-offer-123"
    };

    console.log('📤 إرسال البيانات:', JSON.stringify(orderData, null, 2));

    const curlCommand = `curl -X POST http://localhost:3000/api/orders \
      -H "Content-Type: application/json" \
      -d '${JSON.stringify(orderData)}' \
      -v`;

    exec(curlCommand, (error, stdout, stderr) => {
      if (error) {
        console.error('❌ خطأ في تنفيذ curl:', error);
        return;
      }
      
      if (stderr) {
        console.log('📋 سجلات curl:', stderr);
      }
      
      try {
        const result = JSON.parse(stdout);
        console.log('📥 استجابة الخادم:', JSON.stringify(result, null, 2));
        
        if (result.success) {
          console.log('✅ تم إنشاء الطلب بنجاح!');
          console.log('🆔 معرف الطلب:', result.order.id);
          console.log('📅 تاريخ الإنشاء:', result.order.created_at);
          
          // انتظار قليلاً ثم التحقق من قاعدة البيانات
          setTimeout(() => {
            console.log('\n🔍 التحقق من قاعدة البيانات...');
            const checkCommand = `node scripts/check_recent_orders.js`;
            exec(checkCommand, (checkError, checkStdout, checkStderr) => {
              if (checkError) {
                console.error('❌ خطأ في التحقق:', checkError);
                return;
              }
              console.log('📊 نتائج التحقق:');
              console.log(checkStdout);
            });
          }, 2000);
          
        } else {
          console.log('❌ فشل في إنشاء الطلب');
          console.log('🚨 رسالة الخطأ:', result.error);
        }
      } catch (parseError) {
        console.error('❌ خطأ في تحليل الاستجابة:', parseError);
        console.log('📄 الاستجابة الخام:', stdout);
      }
    });

  } catch (error) {
    console.error('❌ خطأ في الاختبار:', error);
  }
}

testApiWithLogs();
