const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL || process.env.DATABASE_URL,
});

async function createCorrectData() {
  try {
    console.log('إنشاء البيانات الصحيحة...');

    // استخدام المنتج الأول الموجود
    const productResult = await pool.query('SELECT id, name, price FROM products LIMIT 1');
    const productId = productResult.rows[0].id;
    console.log('المنتج المستخدم:', productResult.rows[0]);

    // استخدام المستخدم الأول
    const userResult = await pool.query('SELECT id, username, full_name FROM users LIMIT 1');
    const userId = userResult.rows[0].id;
    console.log('المستخدم المستخدم:', userResult.rows[0]);

    // إنشاء رابط إعادة بيع بالـ slug المطلوب
    const resellLinkResult = await pool.query(`
      INSERT INTO resell_links (id, slug, item_type, product_id, user_id, reseller_price, is_active, created_at)
      VALUES (
        gen_random_uuid(),
        'og7ctmMHO83i',
        'product',
        $1,
        $2,
        85000,
        true,
        NOW()
      )
      ON CONFLICT (slug) DO UPDATE SET
        product_id = EXCLUDED.product_id,
        user_id = EXCLUDED.user_id,
        reseller_price = EXCLUDED.reseller_price,
        is_active = EXCLUDED.is_active
      RETURNING id, slug, reseller_price
    `, [productId, userId]);

    console.log('تم إنشاء رابط إعادة البيع:', resellLinkResult.rows[0]);

    console.log('✅ تم إنشاء البيانات الصحيحة بنجاح!');
    console.log('يمكنك الآن اختبار الرابط: /resell/og7ctmMHO83i');

  } catch (error) {
    console.error('❌ خطأ في إنشاء البيانات:', error);
  } finally {
    await pool.end();
  }
}

createCorrectData();
