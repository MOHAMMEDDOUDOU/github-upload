const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL || process.env.DATABASE_URL,
});

async function checkData() {
  try {
    console.log('التحقق من البيانات في قاعدة البيانات...');
    
    // التحقق من resell_links
    console.log('\n=== روابط إعادة البيع ===');
    const resellLinks = await pool.query('SELECT id, slug, item_type, product_id, user_id, reseller_price, is_active FROM resell_links');
    console.log('عدد الروابط:', resellLinks.rows.length);
    resellLinks.rows.forEach((link, index) => {
      console.log(`${index + 1}. Slug: ${link.slug}, Type: ${link.item_type}, Active: ${link.is_active}`);
    });

    // التحقق من المنتجات
    console.log('\n=== المنتجات ===');
    const products = await pool.query('SELECT id, name, price, is_active FROM products LIMIT 5');
    console.log('عدد المنتجات:', products.rows.length);
    products.rows.forEach((product, index) => {
      console.log(`${index + 1}. ID: ${product.id}, Name: ${product.name}, Price: ${product.price}, Active: ${product.is_active}`);
    });

    // التحقق من المستخدمين
    console.log('\n=== المستخدمون ===');
    const users = await pool.query('SELECT id, username, full_name FROM users LIMIT 3');
    console.log('عدد المستخدمين:', users.rows.length);
    users.rows.forEach((user, index) => {
      console.log(`${index + 1}. ID: ${user.id}, Username: ${user.username}, Name: ${user.full_name}`);
    });

  } catch (error) {
    console.error('❌ خطأ في التحقق من البيانات:', error);
  } finally {
    await pool.end();
  }
}

checkData();
