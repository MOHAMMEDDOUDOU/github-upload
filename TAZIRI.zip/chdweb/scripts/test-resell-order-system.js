const { Pool } = require('pg');

// تكوين الاتصال بقاعدة البيانات
const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function testResellOrderSystem() {
  try {
    console.log('🧪 بدء اختبار نظام طلبات إعادة البيع...\n');

    // 1. اختبار إنشاء رابط إعادة البيع
    console.log('1️⃣ اختبار إنشاء رابط إعادة البيع...');
    
    const testSlug = `test-${Date.now()}`;
    const resellLinkResult = await pool.query(`
      INSERT INTO resell_links (
        slug, item_type, item_id, reseller_name, reseller_phone, custom_price, is_active
      ) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *
    `, [
      testSlug,
      'product',
      '550e8400-e29b-41d4-a716-446655440000', // معرف وهمي للمنتج
      'أحمد محمد',
      '+213123456789',
      1500,
      true
    ]);
    
    console.log('✅ تم إنشاء رابط إعادة البيع:', resellLinkResult.rows[0].slug);

    // 2. اختبار إنشاء طلب من رابط إعادة البيع
    console.log('\n2️⃣ اختبار إنشاء طلب من رابط إعادة البيع...');
    
    const orderResult = await pool.query(`
      INSERT INTO orders (
        item_type, item_id, item_name, quantity, unit_price, subtotal, shipping_cost, total_amount,
        customer_name, phone_number, wilaya, commune, delivery_type, status,
        reseller_price, reseller_name, reseller_phone, resell_link_id, resell_link_slug, address
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20) RETURNING *
    `, [
      'product',
      '550e8400-e29b-41d4-a716-446655440000',
      'منتج تجريبي',
      2,
      1500,
      3000,
      500,
      3500,
      'محمد علي',
      '+213987654321',
      'الجزائر',
      'الجزائر الوسطى',
      'home',
      'قيد المعالجة',
      1500,
      'أحمد محمد',
      '+213123456789',
      resellLinkResult.rows[0].id,
      testSlug,
      'شارع الرئيسي، رقم 123'
    ]);
    
    console.log('✅ تم إنشاء الطلب:', orderResult.rows[0].id);

    // 3. اختبار جلب الطلبات المرتبطة برابط إعادة البيع
    console.log('\n3️⃣ اختبار جلب الطلبات المرتبطة برابط إعادة البيع...');
    
    const ordersResult = await pool.query(`
      SELECT * FROM orders WHERE resell_link_slug = $1
    `, [testSlug]);
    
    console.log('✅ تم العثور على', ordersResult.rows.length, 'طلب مرتبط برابط إعادة البيع');

    // 4. اختبار جلب إحصائيات رابط إعادة البيع
    console.log('\n4️⃣ اختبار جلب إحصائيات رابط إعادة البيع...');
    
    const statsResult = await pool.query(`
      SELECT 
        rl.slug,
        rl.views_count,
        rl.clicks_count,
        COUNT(o.id) as orders_count,
        SUM(o.total_amount) as total_revenue
      FROM resell_links rl
      LEFT JOIN orders o ON rl.slug = o.resell_link_slug
      WHERE rl.slug = $1
      GROUP BY rl.slug, rl.views_count, rl.clicks_count
    `, [testSlug]);
    
    if (statsResult.rows.length > 0) {
      const stats = statsResult.rows[0];
      console.log('✅ إحصائيات رابط إعادة البيع:');
      console.log(`   - المشاهدات: ${stats.views_count}`);
      console.log(`   - النقرات: ${stats.clicks_count}`);
      console.log(`   - الطلبات: ${stats.orders_count}`);
      console.log(`   - الإيرادات: ${stats.total_revenue} دج`);
    }

    // 5. اختبار التحقق من هيكل الجدول
    console.log('\n5️⃣ اختبار التحقق من هيكل جدول الطلبات...');
    
    const columnsResult = await pool.query(`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns 
      WHERE table_name = 'orders' 
      AND column_name IN ('reseller_name', 'reseller_phone', 'reseller_user_id', 'resell_link_id', 'resell_link_slug', 'address')
      ORDER BY column_name;
    `);
    
    console.log('✅ الأعمدة الجديدة في جدول الطلبات:');
    columnsResult.rows.forEach(row => {
      console.log(`   - ${row.column_name}: ${row.data_type} (${row.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'})`);
    });

    // 6. تنظيف البيانات التجريبية
    console.log('\n6️⃣ تنظيف البيانات التجريبية...');
    
    await pool.query('DELETE FROM orders WHERE resell_link_slug = $1', [testSlug]);
    await pool.query('DELETE FROM resell_links WHERE slug = $1', [testSlug]);
    
    console.log('✅ تم تنظيف البيانات التجريبية');

    console.log('\n🎉 تم اختبار نظام طلبات إعادة البيع بنجاح!');
    console.log('\n📋 ملخص الاختبارات:');
    console.log('✅ إنشاء رابط إعادة البيع');
    console.log('✅ إنشاء طلب من رابط إعادة البيع');
    console.log('✅ جلب الطلبات المرتبطة');
    console.log('✅ جلب الإحصائيات');
    console.log('✅ التحقق من هيكل الجدول');
    console.log('✅ تنظيف البيانات التجريبية');

  } catch (error) {
    console.error('❌ خطأ في اختبار نظام طلبات إعادة البيع:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

// تشغيل الاختبار إذا تم استدعاء الملف مباشرة
if (require.main === module) {
  testResellOrderSystem()
    .then(() => {
      console.log('\n✅ تم الانتهاء من جميع الاختبارات');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n❌ فشل في الاختبارات:', error);
      process.exit(1);
    });
}

module.exports = { testResellOrderSystem };
