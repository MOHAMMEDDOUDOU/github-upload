const { exec } = require('child_process');

async function testOrderCreation() {
  try {
    console.log('🧪 اختبار إنشاء طلب جديد...');

    const orderData = {
      resell_link_id: "fd9e719b-ed15-4d75-8c53-8d5d36966cf6",
      item_type: "product",
      item_id: "8dae8c99-2655-41b1-91b1-7e6a088d3712",
      item_name: "منتج تجريبي للاختبار",
      original_price: 1500.00,
      reseller_price: 1800.00,
      quantity: 2,
      total_amount: 3600.00,
      seller_id: "628b27dc-dff1-490d-9b3b-b97ec4260caf",
      seller_name: "بائع تجريبي",
      seller_phone: "0550123457",
      customer_name: "عميل تجريبي",
      customer_phone: "0550123458",
      delivery_type: "home",
      wilaya: 16,
      commune: "بلدية تجريبية",
      notes: "طلب تجريبي للاختبار"
    };

    console.log('📤 إرسال بيانات الطلب:', JSON.stringify(orderData, null, 2));

    const curlCommand = `curl -X POST http://localhost:3000/api/orders \
      -H "Content-Type: application/json" \
      -d '${JSON.stringify(orderData)}'`;

    exec(curlCommand, (error, stdout, stderr) => {
      if (error) {
        console.error('❌ خطأ في تنفيذ curl:', error);
        return;
      }
      
      if (stderr) {
        console.error('❌ خطأ في الاستجابة:', stderr);
        return;
      }
      
      try {
        const result = JSON.parse(stdout);
        console.log('📥 استجابة الخادم:', JSON.stringify(result, null, 2));
        
        if (result.success) {
          console.log('✅ تم إنشاء الطلب بنجاح!');
          console.log('🆔 رقم الطلب:', result.order.order_number);
          console.log('📅 تاريخ الإنشاء:', result.order.created_at);
        } else {
          console.log('❌ فشل في إنشاء الطلب');
          console.log('🚨 رسالة الخطأ:', result.error);
        }
      } catch (parseError) {
        console.error('❌ خطأ في تحليل الاستجابة:', parseError);
        console.log('📄 الاستجابة الخام:', stdout);
      }
    });

  } catch (error) {
    console.error('❌ خطأ في الاختبار:', error);
  }
}

testOrderCreation();
