const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL || process.env.DATABASE_URL,
});

async function checkUsers() {
  try {
    console.log('التحقق من المستخدمين الموجودين...');
    
    const result = await pool.query('SELECT id, username, full_name, phone_number FROM users LIMIT 5');
    
    console.log('المستخدمون الموجودون:');
    result.rows.forEach((user, index) => {
      console.log(`${index + 1}. ID: ${user.id}, Username: ${user.username}, Name: ${user.full_name}, Phone: ${user.phone_number}`);
    });

  } catch (error) {
    console.error('❌ خطأ في التحقق من المستخدمين:', error);
  } finally {
    await pool.end();
  }
}

checkUsers();
