require('dotenv').config();
const { Pool } = require('pg');

async function createResellLinksTable() {
  console.log('🔧 إنشاء جدول روابط إعادة البيع...');
  
  if (!process.env.NEON_DATABASE_URL) {
    console.error('❌ متغير NEON_DATABASE_URL غير موجود');
    return;
  }

  const pool = new Pool({
    connectionString: process.env.NEON_DATABASE_URL,
    ssl: { rejectUnauthorized: false }
  });

  try {
    // إنشاء الجدول مباشرة
    console.log('📝 إنشاء جدول resell_links...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS resell_links (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        slug VARCHAR(100) UNIQUE NOT NULL,
        item_type VARCHAR(20) NOT NULL DEFAULT 'product',
        item_id UUID NOT NULL,
        reseller_user_id UUID,
        reseller_name VARCHAR(255),
        reseller_phone VARCHAR(30),
        custom_price DECIMAL(10,2),
        is_active BOOLEAN DEFAULT true,
        views_count INTEGER DEFAULT 0,
        clicks_count INTEGER DEFAULT 0,
        expires_at TIMESTAMP WITH TIME ZONE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `);
    
    console.log('✅ تم إنشاء الجدول بنجاح!');

    // إنشاء الفهارس
    console.log('📝 إنشاء الفهارس...');
    await pool.query('CREATE INDEX IF NOT EXISTS idx_resell_links_slug ON resell_links(slug);');
    await pool.query('CREATE INDEX IF NOT EXISTS idx_resell_links_item ON resell_links(item_type, item_id);');
    await pool.query('CREATE INDEX IF NOT EXISTS idx_resell_links_reseller ON resell_links(reseller_user_id);');
    await pool.query('CREATE INDEX IF NOT EXISTS idx_resell_links_active ON resell_links(is_active);');
    await pool.query('CREATE INDEX IF NOT EXISTS idx_resell_links_expires ON resell_links(expires_at);');
    
    console.log('✅ تم إنشاء الفهارس بنجاح!');

    // التحقق من الجداول
    const tablesResult = await pool.query(`
      SELECT table_name FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name = 'resell_links'
      ORDER BY table_name;
    `);
    
    console.log('📊 الجداول الموجودة:', tablesResult.rows.map(row => row.table_name));

    // التحقق من هيكل الجدول
    const columnsResult = await pool.query(`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns 
      WHERE table_name = 'resell_links' 
      ORDER BY ordinal_position;
    `);
    
    console.log('📋 أعمدة جدول روابط إعادة البيع:');
    columnsResult.rows.forEach(row => {
      console.log(`  - ${row.column_name}: ${row.data_type} (${row.is_nullable === 'YES' ? 'NULL' : 'NOT NULL'})`);
    });

    console.log('🎉 تم إنشاء نظام روابط إعادة البيع بنجاح!');

  } catch (error) {
    console.error('❌ خطأ في إنشاء جدول روابط إعادة البيع:', error.message);
  } finally {
    await pool.end();
  }
}

createResellLinksTable();
