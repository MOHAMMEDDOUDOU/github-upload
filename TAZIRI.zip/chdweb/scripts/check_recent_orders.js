const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function checkRecentOrders() {
  const client = await pool.connect();
  
  try {
    console.log('🔍 التحقق من الطلبات الحديثة...');

    // التحقق من عدد الطلبات الإجمالي
    const totalOrders = await client.query(`
      SELECT COUNT(*) as total FROM orders;
    `);
    
    console.log('📊 إجمالي عدد الطلبات:', totalOrders.rows[0].total);

    // عرض آخر 5 طلبات
    const recentOrders = await client.query(`
      SELECT 
        id,
        item_name,
        customer_name,
        phone_number,
        quantity,
        total_amount,
        status,
        created_at,
        order_link
      FROM orders 
      ORDER BY created_at DESC 
      LIMIT 5;
    `);
    
    console.log('📋 آخر 5 طلبات:');
    recentOrders.rows.forEach((order, index) => {
      console.log(`\n${index + 1}. طلب رقم: ${order.id}`);
      console.log(`   المنتج: ${order.item_name}`);
      console.log(`   العميل: ${order.customer_name}`);
      console.log(`   الهاتف: ${order.phone_number}`);
      console.log(`   الكمية: ${order.quantity}`);
      console.log(`   المبلغ: ${order.total_amount}`);
      console.log(`   الحالة: ${order.status}`);
      console.log(`   التاريخ: ${order.created_at}`);
      console.log(`   الرابط: ${order.order_link}`);
    });

    // البحث عن طلب معين
    const specificOrder = await client.query(`
      SELECT * FROM orders 
      WHERE phone_number = '0550123460' 
      ORDER BY created_at DESC 
      LIMIT 1;
    `);
    
    if (specificOrder.rows.length > 0) {
      console.log('\n✅ تم العثور على الطلب المحدد:');
      console.log(JSON.stringify(specificOrder.rows[0], null, 2));
    } else {
      console.log('\n❌ لم يتم العثور على الطلب المحدد');
    }

  } catch (error) {
    console.error('❌ خطأ في التحقق من الطلبات:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

checkRecentOrders().catch(console.error);
