require('dotenv').config();
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

// تكوين الاتصال بقاعدة البيانات
const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

async function updateOrdersTable() {
  try {
    console.log('بدء تحديث جدول الطلبات...');
    
    // قراءة ملف SQL
    const sqlFile = path.join(__dirname, '../database/update-orders-resell.sql');
    const sql = fs.readFileSync(sqlFile, 'utf8');
    
    // تنفيذ الاستعلامات
    const result = await pool.query(sql);
    
    console.log('تم تحديث جدول الطلبات بنجاح!');
    console.log('تم إضافة الأعمدة الجديدة:');
    console.log('- reseller_name');
    console.log('- reseller_phone');
    console.log('- reseller_user_id');
    console.log('- resell_link_id');
    console.log('- resell_link_slug');
    console.log('- address');
    
  } catch (error) {
    console.error('خطأ في تحديث جدول الطلبات:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

// تشغيل التحديث إذا تم استدعاء الملف مباشرة
if (require.main === module) {
  updateOrdersTable()
    .then(() => {
      console.log('تم الانتهاء من التحديث');
      process.exit(0);
    })
    .catch((error) => {
      console.error('فشل في التحديث:', error);
      process.exit(1);
    });
}

module.exports = { updateOrdersTable };
