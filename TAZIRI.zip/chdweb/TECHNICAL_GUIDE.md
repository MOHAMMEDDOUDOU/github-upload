# 🔧 الدليل التقني لتطوير تطبيق TANAMIRT الجوال

## 📋 **نظرة عامة على النظام**

### **البنية الحالية للموقع:**
```
Frontend: Next.js 15.2.4 + React 19
Backend: Next.js API Routes
Database: PostgreSQL (Neon)
Authentication: Custom JWT
Image Storage: Cloudinary
Styling: Tailwind CSS + Radix UI
```

### **API Endpoints المتاحة:**
```
GET /api/products - جلب جميع المنتجات
GET /api/products/[id] - جلب منتج واحد
POST /api/products - إضافة منتج جديد
PUT /api/products/[id] - تحديث منتج
DELETE /api/products/[id] - حذف منتج

GET /api/offers - جلب جميع العروض
GET /api/offers/[id] - جلب عرض واحد
POST /api/offers - إضافة عرض جديد
PUT /api/offers/[id] - تحديث عرض
DELETE /api/offers/[id] - حذف عرض

POST /api/orders - إنشاء طلب جديد
GET /api/orders - جلب الطلبات (للمدير)

POST /api/auth/login - تسجيل الدخول
POST /api/auth/register - تسجيل حساب جديد
GET /api/auth/me - معلومات المستخدم الحالي
POST /api/auth/logout - تسجيل الخروج
```

## 🗄️ **هيكل قاعدة البيانات**

### **جدول المنتجات (products):**
```sql
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    discount_price DECIMAL(10,2),
    discount_percentage INTEGER,
    image_url TEXT,
    stock_quantity INTEGER NOT NULL DEFAULT 0,
    sizes JSONB,
    images JSONB,
    category VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### **جدول العروض (offers):**
```sql
CREATE TABLE offers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    discount_price DECIMAL(10,2),
    image_url TEXT,
    stock_quantity INTEGER NOT NULL DEFAULT 0,
    sizes JSONB,
    images JSONB,
    category VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### **جدول الطلبات (orders):**
```sql
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_type VARCHAR(20) NOT NULL DEFAULT 'product',
    item_id UUID NOT NULL,
    item_name VARCHAR(255) NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    shipping_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(30) NOT NULL,
    wilaya VARCHAR(100) NOT NULL,
    commune VARCHAR(100),
    delivery_type VARCHAR(20) NOT NULL DEFAULT 'home',
    status VARCHAR(50) NOT NULL DEFAULT 'قيد المعالجة',
    reseller_price DECIMAL(10,2),
    reseller_name VARCHAR(255),
    reseller_phone VARCHAR(30),
    reseller_user_id UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

## 🚀 **إعداد مشروع React Native**

### **1. تثبيت الأدوات المطلوبة:**
```bash
# تثبيت Node.js (إذا لم يكن مثبتاً)
# تثبيت Expo CLI
npm install -g @expo/cli

# تثبيت React Native CLI (اختياري)
npm install -g react-native-cli
```

### **2. إنشاء المشروع:**
```bash
# إنشاء مشروع Expo جديد
npx create-expo-app TanamirtMobile --template blank-typescript

# الانتقال للمجلد
cd TanamirtMobile

# تثبيت المكتبات الأساسية
npm install @react-navigation/native @react-navigation/stack @react-navigation/bottom-tabs
npm install @react-native-async-storage/async-storage
npm install react-native-vector-icons
npm install react-native-elements
npm install react-native-gesture-handler
npm install react-native-reanimated
npm install react-native-safe-area-context
npm install react-native-screens
npm install axios
npm install react-native-image-picker
npm install react-native-share
npm install react-native-push-notification
```

### **3. إعداد التكوين الأساسي:**

#### **app.json:**
```json
{
  "expo": {
    "name": "TANAMIRT",
    "slug": "tanamirt-mobile",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "userInterfaceStyle": "light",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#f97316"
    },
    "assetBundlePatterns": [
      "**/*"
    ],
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.tanamirt.mobile"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#f97316"
      },
      "package": "com.tanamirt.mobile"
    },
    "web": {
      "favicon": "./assets/favicon.png"
    },
    "plugins": [
      "expo-font",
      "expo-localization"
    ]
  }
}
```

#### **babel.config.js:**
```javascript
module.exports = function(api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      'react-native-reanimated/plugin',
    ],
  };
};
```

## 🎨 **إعداد التصميم**

### **1. نظام الألوان:**
```typescript
// constants/Colors.ts
export const Colors = {
  primary: '#f97316', // البرتقالي الرئيسي
  primaryDark: '#ea580c',
  secondary: '#6b7280', // الرمادي
  background: '#f9fafb',
  surface: '#ffffff',
  text: '#1f2937',
  textSecondary: '#6b7280',
  border: '#e5e7eb',
  success: '#10b981',
  error: '#ef4444',
  warning: '#f59e0b',
  info: '#3b82f6',
};
```

### **2. الخطوط:**
```typescript
// constants/Fonts.ts
import { Platform } from 'react-native';

export const Fonts = {
  regular: Platform.select({
    ios: 'System',
    android: 'Roboto',
  }),
  medium: Platform.select({
    ios: 'System',
    android: 'Roboto-Medium',
  }),
  bold: Platform.select({
    ios: 'System',
    android: 'Roboto-Bold',
  }),
};
```

### **3. المكونات الأساسية:**
```typescript
// components/Button.tsx
import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { Colors, Fonts } from '../constants';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  disabled = false,
}) => {
  return (
    <TouchableOpacity
      style={[
        styles.button,
        styles[variant],
        styles[size],
        disabled && styles.disabled,
      ]}
      onPress={onPress}
      disabled={disabled}
    >
      <Text style={[styles.text, styles[`${variant}Text`]]}>
        {title}
      </Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primary: {
    backgroundColor: Colors.primary,
  },
  secondary: {
    backgroundColor: Colors.secondary,
  },
  outline: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.primary,
  },
  small: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  medium: {
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  large: {
    paddingHorizontal: 32,
    paddingVertical: 16,
  },
  disabled: {
    opacity: 0.5,
  },
  text: {
    fontFamily: Fonts.medium,
    fontSize: 16,
  },
  primaryText: {
    color: 'white',
  },
  secondaryText: {
    color: 'white',
  },
  outlineText: {
    color: Colors.primary,
  },
});
```

## 🔌 **إعداد API Client**

### **1. إعداد Axios:**
```typescript
// services/api.ts
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_BASE_URL = 'https://your-domain.com/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// إضافة token للمصادقة
api.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// معالجة الأخطاء
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // حذف token وإعادة توجيه لتسجيل الدخول
      await AsyncStorage.removeItem('authToken');
      // إعادة توجيه لشاشة تسجيل الدخول
    }
    return Promise.reject(error);
  }
);

export default api;
```

### **2. خدمات API:**
```typescript
// services/products.ts
import api from './api';

export interface Product {
  id: string;
  name: string;
  description?: string;
  price: number;
  discount_price?: number;
  discount_percentage?: number;
  image_url?: string;
  stock_quantity: number;
  sizes?: string[];
  images?: string[];
  category?: string;
  is_active?: boolean;
  created_at?: string;
  updated_at?: string;
}

export const productsApi = {
  // جلب جميع المنتجات
  getAll: async (): Promise<Product[]> => {
    const response = await api.get('/products');
    return response.data;
  },

  // جلب منتج واحد
  getById: async (id: string): Promise<Product> => {
    const response = await api.get(`/products/${id}`);
    return response.data;
  },

  // البحث في المنتجات
  search: async (filters: {
    category?: string;
    priceMin?: number;
    priceMax?: number;
    name?: string;
  }): Promise<Product[]> => {
    const response = await api.get('/products', { params: filters });
    return response.data;
  },
};
```

## 📱 **هيكل التطبيق**

### **1. التنقل:**
```typescript
// navigation/AppNavigator.tsx
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import SplashScreen from '../screens/SplashScreen';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import HomeScreen from '../screens/HomeScreen';
import ProductsScreen from '../screens/ProductsScreen';
import ProductDetailScreen from '../screens/ProductDetailScreen';
import CartScreen from '../screens/CartScreen';
import ProfileScreen from '../screens/ProfileScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const MainTabs = () => (
  <Tab.Navigator>
    <Tab.Screen name="Home" component={HomeScreen} />
    <Tab.Screen name="Products" component={ProductsScreen} />
    <Tab.Screen name="Cart" component={CartScreen} />
    <Tab.Screen name="Profile" component={ProfileScreen} />
  </Tab.Navigator>
);

const AppNavigator = () => (
  <NavigationContainer>
    <Stack.Navigator initialRouteName="Splash">
      <Stack.Screen name="Splash" component={SplashScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Register" component={RegisterScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Main" component={MainTabs} options={{ headerShown: false }} />
      <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
    </Stack.Navigator>
  </NavigationContainer>
);

export default AppNavigator;
```

### **2. إدارة الحالة:**
```typescript
// store/AppContext.tsx
import React, { createContext, useContext, useReducer } from 'react';

interface AppState {
  user: any | null;
  cart: any[];
  isLoading: boolean;
}

type AppAction =
  | { type: 'SET_USER'; payload: any }
  | { type: 'ADD_TO_CART'; payload: any }
  | { type: 'REMOVE_FROM_CART'; payload: string }
  | { type: 'SET_LOADING'; payload: boolean };

const initialState: AppState = {
  user: null,
  cart: [],
  isLoading: false,
};

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'ADD_TO_CART':
      return { ...state, cart: [...state.cart, action.payload] };
    case 'REMOVE_FROM_CART':
      return { ...state, cart: state.cart.filter(item => item.id !== action.payload) };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    default:
      return state;
  }
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
```

## 🧪 **الاختبار**

### **1. اختبار الوحدات:**
```typescript
// __tests__/Button.test.tsx
import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import { Button } from '../components/Button';

describe('Button Component', () => {
  it('renders correctly', () => {
    const { getByText } = render(
      <Button title="Test Button" onPress={() => {}} />
    );
    expect(getByText('Test Button')).toBeTruthy();
  });

  it('calls onPress when pressed', () => {
    const onPressMock = jest.fn();
    const { getByText } = render(
      <Button title="Test Button" onPress={onPressMock} />
    );
    
    fireEvent.press(getByText('Test Button'));
    expect(onPressMock).toHaveBeenCalledTimes(1);
  });
});
```

### **2. اختبار التكامل:**
```typescript
// __tests__/api.test.ts
import { productsApi } from '../services/products';

describe('Products API', () => {
  it('fetches products successfully', async () => {
    const products = await productsApi.getAll();
    expect(Array.isArray(products)).toBe(true);
  });
});
```

## 📦 **النشر**

### **1. إعداد Expo Build:**
```bash
# بناء للتطبيق
expo build:android
expo build:ios

# أو استخدام EAS Build
eas build --platform android
eas build --platform ios
```

### **2. إعداد متاجر التطبيقات:**
- إنشاء حساب في Google Play Console
- إنشاء حساب في Apple Developer Program
- إعداد الشهادات والمفاتيح
- رفع التطبيق للمراجعة

## 🔒 **الأمان**

### **1. تشفير البيانات:**
```typescript
// utils/encryption.ts
import CryptoJS from 'crypto-js';

const SECRET_KEY = 'your-secret-key';

export const encryptData = (data: string): string => {
  return CryptoJS.AES.encrypt(data, SECRET_KEY).toString();
};

export const decryptData = (encryptedData: string): string => {
  const bytes = CryptoJS.AES.decrypt(encryptedData, SECRET_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
};
```

### **2. حماية API:**
- استخدام HTTPS
- التحقق من صحة JWT tokens
- حماية من CSRF attacks
- Rate limiting

## 📊 **المراقبة والتحليلات**

### **1. إعداد Firebase Analytics:**
```typescript
// services/analytics.ts
import analytics from '@react-native-firebase/analytics';

export const trackEvent = (eventName: string, parameters?: object) => {
  analytics().logEvent(eventName, parameters);
};

export const trackScreen = (screenName: string) => {
  analytics().logScreenView({
    screen_name: screenName,
    screen_class: screenName,
  });
};
```

### **2. إعداد Crashlytics:**
```typescript
// services/crashlytics.ts
import crashlytics from '@react-native-firebase/crashlytics';

export const logError = (error: Error, context?: object) => {
  crashlytics().recordError(error);
  if (context) {
    crashlytics().log(JSON.stringify(context));
  }
};
```

---

*هذا الدليل يوفر الأساس التقني لتطوير تطبيق TANAMIRT الجوال. يمكن تخصيصه حسب المتطلبات المحددة.*
