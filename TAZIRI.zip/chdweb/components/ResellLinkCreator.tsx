'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Copy, ExternalLink, Link, Calendar, DollarSign } from 'lucide-react';
import { toast } from 'sonner';

interface Product {
  id: string;
  name: string;
  price: number;
  image_url?: string;
  category?: string;
}

interface Offer {
  id: string;
  name: string;
  price: number;
  image_url?: string;
  category?: string;
}

interface ResellLinkCreatorProps {
  products: Product[];
  offers: Offer[];
  user?: {
    id: string;
    full_name: string;
    phone_number: string;
  };
}

export default function ResellLinkCreator({ products, offers, user }: ResellLinkCreatorProps) {
  const [selectedType, setSelectedType] = useState<'product' | 'offer'>('product');
  const [selectedItem, setSelectedItem] = useState<string>('');
  const [customPrice, setCustomPrice] = useState<string>('');
  const [resellerName, setResellerName] = useState<string>(user?.full_name || '');
  const [resellerPhone, setResellerPhone] = useState<string>(user?.phone_number || '');
  const [expiresAt, setExpiresAt] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [createdLink, setCreatedLink] = useState<any>(null);

  const items = selectedType === 'product' ? products : offers;
  const selectedItemData = items.find(item => item.id === selectedItem);

  const handleCreateLink = async () => {
    if (!selectedItem) {
      toast.error('يرجى اختيار منتج أو عرض');
      return;
    }

    if (!user && (!resellerName || !resellerPhone)) {
      toast.error('يرجى إدخال اسم البائع ورقم الهاتف');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/resell-links', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          item_type: selectedType,
          item_id: selectedItem,
          reseller_user_id: user?.id || null,
          reseller_name: resellerName || null,
          reseller_phone: resellerPhone || null,
          custom_price: customPrice ? parseFloat(customPrice) : null,
          expires_at: expiresAt || null,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'خطأ في إنشاء الرابط');
      }

      const result = await response.json();
      setCreatedLink(result);
      toast.success('تم إنشاء رابط إعادة البيع بنجاح!');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'خطأ في إنشاء الرابط');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success('تم نسخ الرابط!');
    } catch (error) {
      toast.error('خطأ في نسخ الرابط');
    }
  };

  const resetForm = () => {
    setSelectedItem('');
    setCustomPrice('');
    setExpiresAt('');
    setCreatedLink(null);
  };

  return (
    <div className="space-y-6">
      {/* Form Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link className="h-5 w-5" />
            إنشاء رابط إعادة البيع
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Type Selection */}
          <div className="space-y-2">
            <Label>نوع العنصر</Label>
            <Select value={selectedType} onValueChange={(value: 'product' | 'offer') => setSelectedType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="product">منتج</SelectItem>
                <SelectItem value="offer">عرض</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Item Selection */}
          <div className="space-y-2">
            <Label>اختر {selectedType === 'product' ? 'المنتج' : 'العرض'}</Label>
            <Select value={selectedItem} onValueChange={setSelectedItem}>
              <SelectTrigger>
                <SelectValue placeholder={`اختر ${selectedType === 'product' ? 'منتج' : 'عرض'}`} />
              </SelectTrigger>
              <SelectContent>
                {items.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name} - {item.price.toLocaleString()} دج
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Selected Item Preview */}
          {selectedItemData && (
            <Card className="bg-gray-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  {selectedItemData.image_url && (
                    <img
                      src={selectedItemData.image_url}
                      alt={selectedItemData.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                  )}
                  <div className="flex-1">
                    <h4 className="font-semibold">{selectedItemData.name}</h4>
                    <p className="text-gray-600">{selectedItemData.category}</p>
                    <p className="text-lg font-bold text-pink-600">
                      {selectedItemData.price.toLocaleString()} دج
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Custom Price */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              السعر المخصص (اختياري)
            </Label>
            <Input
              type="number"
              placeholder="أدخل السعر المخصص"
              value={customPrice}
              onChange={(e) => setCustomPrice(e.target.value)}
            />
            <p className="text-sm text-gray-500">
              اتركه فارغاً لاستخدام السعر الأصلي
            </p>
          </div>

          {/* Reseller Info (if not logged in) */}
          {!user && (
            <>
              <Separator />
              <div className="space-y-4">
                <h4 className="font-semibold">معلومات البائع</h4>
                
                <div className="space-y-2">
                  <Label>اسم البائع</Label>
                  <Input
                    placeholder="أدخل اسم البائع"
                    value={resellerName}
                    onChange={(e) => setResellerName(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>رقم الهاتف</Label>
                  <Input
                    placeholder="أدخل رقم الهاتف"
                    value={resellerPhone}
                    onChange={(e) => setResellerPhone(e.target.value)}
                  />
                </div>
              </div>
            </>
          )}

          {/* Expiration Date */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              تاريخ انتهاء الصلاحية (اختياري)
            </Label>
            <Input
              type="datetime-local"
              value={expiresAt}
              onChange={(e) => setExpiresAt(e.target.value)}
            />
          </div>

          {/* Create Button */}
          <Button 
            onClick={handleCreateLink}
            disabled={loading || !selectedItem}
            className="w-full"
          >
            {loading ? 'جاري الإنشاء...' : 'إنشاء رابط إعادة البيع'}
          </Button>
        </CardContent>
      </Card>

      {/* Created Link Card */}
      {createdLink && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800">تم إنشاء الرابط بنجاح!</CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>رابط المشاركة</Label>
              <div className="flex gap-2">
                <Input
                  value={createdLink.share_url}
                  readOnly
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  onClick={() => copyToClipboard(createdLink.share_url)}
                >
                  <Copy className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.open(createdLink.share_url, '_blank')}
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">الرابط المختصر:</span>
                <p className="font-mono font-semibold">{createdLink.link.slug}</p>
              </div>
              <div>
                <span className="text-gray-600">السعر النهائي:</span>
                <p className="font-semibold text-green-600">
                  {createdLink.item.final_price.toLocaleString()} دج
                </p>
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={resetForm} variant="outline" className="flex-1">
                إنشاء رابط جديد
              </Button>
              <Button 
                onClick={() => window.open(createdLink.share_url, '_blank')}
                className="flex-1"
              >
                عرض الرابط
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
